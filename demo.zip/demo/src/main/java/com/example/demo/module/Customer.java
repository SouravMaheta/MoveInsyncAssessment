package com.example.demo.module;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Data
@Document
public class Customer {
    @Id
    private int Customer_id;
    private String Customer_Name;
    private String city;
    private String  Email;
    private int mob;

}
