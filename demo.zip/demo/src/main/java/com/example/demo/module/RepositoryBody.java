package com.example.demo.module;

public @interface RepositoryBody {
}
