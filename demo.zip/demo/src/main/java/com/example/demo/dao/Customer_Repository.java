package com.example.demo.dao;

import com.example.demo.module.Customer;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface Customer_Repository extends MongoRepository<Customer,Integer>{
}
