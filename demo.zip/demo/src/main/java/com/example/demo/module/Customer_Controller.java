package com.example.demo.module;

import com.example.demo.dao.Customer_Repository;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import org.springframework.data.annotation.Id;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.Optional;

@RestController
@RequestMapping("/api")
public class Customer_Controller {
    private Customer_Repository customer_repository;
    @PostMapping("/addCustomer")
    public String addCustomer(@RepositoryBody Customer customer){
        customer_repository.save(customer);
        return "customer has been added with the id: "+customer.getCustomer_id();
    }
    @GetMapping("/getCustomer")
    public List<Customer> getCustomer(){

        return customer_repository.findAll();
    }

    @PutMapping("update/{id}")
    public String updateCustomer(@PathVariable int id, @RequestBody Customer customer){
        boolean exists = customer_repository.existsById(id);
        Customer Customer1 = customer_repository.findAll(Id);


        if(!exists){
            return "the customer does not exist with the id: "+id;
        }

        Customer1.setCustomer_Name(customer.getCustomer_Name());
        //Customer1.set(customer.getSalary());
        customer_repository.save(Customer1);
        return "customer updated with id: "+id;

    }

    @DeleteMapping("delete/{id}")
    public String deleteCustomer(@PathVariable int id){
        customer_repository.deleteById(id);
        return "customer with deleted with the id: "+id;
    }

}
